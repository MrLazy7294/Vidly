﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Vidly.Models;
using Vidly.ViewModels;
using System.Data.Entity;

namespace Vidly.Controllers
{
    public class MoviesController : Controller
    {
        private ApplicationDbContext _context;
        public MoviesController()
        {
            _context  = new ApplicationDbContext();
        }

        protected override void Dispose(bool disposing)
        {
            _context.Dispose();
        }

        public ActionResult New(Movie movies)
        {
            //var movies = GetMovies();
            var genList = _context.Genres.ToList();
            var viewModel = new NewMovieViewModel
            {
                Movie =new Movie(),
                Genre = genList
            };
            return View("MovieForm", viewModel);
        }
        public ActionResult Edit(int id)
        {
            //var movies = GetMovies();
            var movInDb = _context.Movies.Single(c => c.Id == id);
            if (movInDb == null)
                return HttpNotFound();
            var viewModel = new NewMovieViewModel
            {
                Movie = movInDb,
                Genre = _context.Genres
            };
            return View("MovieForm",viewModel);
        }
        [HttpPost]
        public ActionResult Save(Movie movie)
        {           
           if(movie.Id == 0)
            {
                
                movie.DateAdded = DateTime.Now;
                _context.Movies.Add(movie);
            }
            else
            {
                var movieInDb = _context.Movies.Single(m => m.Id == movie.Id);
                movieInDb.Name = movie.Name;
                movieInDb.GenreId = movie.GenreId;
                movieInDb.NumberInStock = movie.NumberInStock;
                movieInDb.ReleaseDate = movie.ReleaseDate;
            }
                _context.SaveChanges();                     
            return RedirectToAction("Index","Movies");
        }




        public ActionResult Index()
        {
            //var movies = GetMovies();
            var movies = _context.Movies.Include(m => m.Genre);
            return View(movies);
        }

        public ActionResult Details(int id)
        {
            var movies = _context.Movies.Include(m => m.Genre).SingleOrDefault(c => c.Id == id);
            if (movies == null)
                return HttpNotFound();
            else
                return View(movies);
        }


    }
}